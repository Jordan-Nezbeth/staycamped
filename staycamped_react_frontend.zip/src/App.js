
import React from 'react';

function App() {
  return (
    <div className="min-h-screen bg-emerald-100 flex flex-col items-center justify-center">
      <header className="bg-emerald-800 text-white w-full p-6 text-center">
        <h1 className="text-4xl font-bold">StayCamped</h1>
        <p className="text-xl">Arrive. Relax. StayCamped.</p>
      </header>
      <main className="flex-1 w-full max-w-4xl p-4">
        <div className="bg-white shadow-lg rounded-xl p-6 text-center">
          <h2 className="text-2xl font-semibold mb-4">Welcome to the Future of Camping</h2>
          <p className="text-gray-700 mb-2">Book a camper that's already set up at your destination. No towing, no hassle.</p>
          <p className="text-gray-700">Own a camper? Let it pay for itself. Host and earn with StayCamped.</p>
        </div>
      </main>
      <footer className="bg-emerald-800 text-white w-full p-4 text-center">
        &copy; 2025 StayCamped
      </footer>
    </div>
  );
}

export default App;
